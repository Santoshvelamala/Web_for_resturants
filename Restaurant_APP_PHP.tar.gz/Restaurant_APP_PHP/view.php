<?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

 $sql = "SELECT * FROM Item";

 $result = $conn->query($sql);


 if($result->num_rows > 0)
 {
echo '<table border="5" align="center">'; 
echo '<caption><h1>Menu</h1></caption>';
echo"<TR><TD align='center'>ItemId</TD><TD align='center'>Item Name</TD><TD align='center'>Price</TD></TR>"; 
while($row = $result->fetch_assoc())
{
echo "<tr><td align='center'>"; 
echo $row['ItemId'];
echo "</td><td align='center'>";   
echo $row['Item_Name'];
echo "</td><td align='center'>";    
echo $row['Price'];
echo "</TD></tr>";  
    
}
echo "</table>";

    }
    else
echo "There was no matching record for the name " . $searchTerm;
?>
