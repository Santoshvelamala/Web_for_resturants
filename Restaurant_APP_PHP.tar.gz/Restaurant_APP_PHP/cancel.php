<?php
session_start();
$id = $_SESSION['id'];
$id= (int)$id;
echo gettype ($id );
?>
<!DOCTYPE html>
<html>
<head>
<style>
.button {
    background-color: #008CBA;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: #555555;} /*  */
</style>
</head>
 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
echo "<body style='background-color:pink'>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$k="Table".$id;

if(!empty($_POST['check_list'])) {
    foreach($_POST['check_list'] as $check) {
		$sql = "select * from Menu natural join Item where ItemId='$check'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		    while($row = $result->fetch_assoc()) {
			echo $a=$row['MenuId'];
			//echo $table;
			$sql = "INSERT INTO Orders (MenuId,TableId)VALUES ('$a','{$id}')";
			$sql1 = "INSERT INTO $k (MenuId,OrderId)VALUES ('$a','{$id}')";
			$orders=(int)$_SESSION['orders'];
			$orders= $orders+1;
			echo $_SESSION['orders']=$orders;
		    }
		} 
		else {
		    echo "0 results";
		}
            

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
if (mysqli_query($conn, $sql1)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
//echoes the value set in the HTML form for each checked checkbox.
                         //so, if I were to check 1, 3, and 5 it would echo value 1, value 3, value 5.
                         //in your case, it would echo whatever $row['Report ID'] is equivalent to.
    }
}
phpAlert(   "Order Placed Successfully"   );
function phpAlert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}
redirect ("/Fcomm/main2.php?id=$id");
function redirect($url, $permanent = false) {
	if($permanent) {
		header('HTTP/1.1 301 Moved Permanently');
	}
	header('Location: '.$url);
	exit();
}
$conn->close();

?>
 

