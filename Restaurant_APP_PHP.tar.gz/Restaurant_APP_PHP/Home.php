 <html>
<style>
#sign_box
{
z-index:9999;
width:180px; 
background-color:#fff; 
border:solid 1px #5ea0c1; 
padding:18px 20px;
position:absolute;
display:none;
-moz-border-radius-topright:6px;
-moz-border-radius-bottomleft:6px;
-moz-border-radius-bottomright:6px;
-webkit-border-top-right-radius:6px;
-webkit-border-bottom-left-radius:6px;
-webkit-border-bottom-right-radius:6px;
}
.sign_in
{
background-color:#FFFFFF;
}
#main
{
height:500px;
}
</style>

<body>
<center>
<h1>S.M. Restaurant</h1>
<a href="DisplayOrd.php">
<button type="button">Orders</button>
</a><br><br>
<a href="Menu.php">
<button type="button">Menu</button>
</a><br><br>
<a href="update.html">
<button type="button">Update</button>
</a><br><br>
<a href="insert.html">
<button type="button">Add</button>
</a><br><br>
<a href="delete.html">
<button type="button">Delete</button>
</a>

</center>


</body>
</html> 
