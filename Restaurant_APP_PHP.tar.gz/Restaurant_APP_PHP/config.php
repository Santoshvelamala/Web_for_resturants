<?php 
mysql_connect("localhost","root","santuharsha") or die ('unable to connect host');
mysql_select_db('fcomm')or die ('unable to connect databse');
?>
