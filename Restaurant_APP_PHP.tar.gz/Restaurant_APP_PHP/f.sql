﻿
/*******************************************************************************
   Chinook Database - Version 1.4
   Script: Chinook_MySql_AutoIncrementPKs.sql
   Description: Creates and populates the Chinook database.
   DB Server: MySql
   Author: Luis Rocha
   License: http://www.codeplex.com/ChinookDatabase/license
********************************************************************************/

/*******************************************************************************
   Drop database if it exists
********************************************************************************/
DROP DATABASE IF EXISTS `fcomm`;


/*******************************************************************************
   Create database
********************************************************************************/
CREATE DATABASE `fcomm`;


USE `fcomm`;


/*******************************************************************************
   Create Tables
********************************************************************************/
CREATE TABLE `Menu`
(
    `MenuId` INT NOT NULL AUTO_INCREMENT,
    `ItemId` INT NOT NULL,
    CONSTRAINT `PK_Menu` PRIMARY KEY  (`MenuId`)
);

CREATE TABLE `Tables`
(
    `TableId` INT NOT NULL AUTO_INCREMENT,
	`Table_Name` NVARCHAR(120),
	`password` varchar(120) NOT NULL,
    CONSTRAINT `PK_Table` PRIMARY KEY  (`TableId`)
);

CREATE TABLE `Orders`
(
    `MenuId` INT NOT NULL,
    `TableId` INT NOT NULL,
    `OrderId` INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT `PK_Order` PRIMARY KEY  (`OrderId`)
);

CREATE TABLE `ManagementLogin`
(
    `Id` INT NOT NULL AUTO_INCREMENT,
	`Name` NVARCHAR(120),
	`password` varchar(120) NOT NULL,
    CONSTRAINT `PK_Table` PRIMARY KEY  (`Id`)
);

CREATE TABLE `Admin`
(
    `Id` INT NOT NULL AUTO_INCREMENT,
	`password` varchar(120) NOT NULL,
    CONSTRAINT `PK_Table` PRIMARY KEY  (`Id`)
);


CREATE TABLE `Item`
(
    `ItemId` INT NOT NULL AUTO_INCREMENT,
    `Item_Name` NVARCHAR(120),
    `Price` INT NOT NULL,
    CONSTRAINT `PK_Item` PRIMARY KEY  (`ItemId`)
);




/*******************************************************************************
   Create Primary Key Unique Indexes
********************************************************************************/

/*******************************************************************************
   Create Foreign Keys
********************************************************************************/


ALTER TABLE `Orders` ADD CONSTRAINT `FK_MenuId1`
    FOREIGN KEY (`MenuId`) REFERENCES `Menu` (`MenuId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `Orders` ADD CONSTRAINT `FK_MenuId2`
    FOREIGN KEY (`TableId`) REFERENCES `Tables` (`TableId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `Menu` ADD CONSTRAINT `FK_ItemId`
    FOREIGN KEY (`ItemId`) REFERENCES `Item` (`ItemId`) ON DELETE NO ACTION ON UPDATE NO ACTION;


/*******************************************************************************
   Populate Tables
********************************************************************************/
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (1, N'Idly', 15);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (2, N'Dosa', 25);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (3, N'Vada', 20);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (4, N'Chilli Chicken', 180);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (5, N'Chicken 65', 150);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (6, N'Tandoori Chicken', 180);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (7, N'Butter Chicken Masala', 150);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (8, N'Mushroom 65', 200);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (9, N'Paneer Pakodi', 160);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (10, N'Butter Paneer', 150);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (11, N'Butter Nan', 30);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (12, N'Plain Roti', 20);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (13, N'Hyderabadi Dum Biryani', 160);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (14, N'Veg Biryani', 150);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (15, N'Chicken Lollypop', 120);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (16, N'Paneer Butter Masala', 150);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (17, N'Chicken Roast', 200);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (18, N'Vanila Icecream', 50);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (19, N'Strawberry Icecream', 50);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (20, N'Chocolate Icecream', 70);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (21, N'Butterscotch Icecream', 70);
INSERT INTO `Item` (`ItemId`, `Item_Name`, `Price`) VALUES (22, N'Coke', 20);


INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (11, 1);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (12, 2);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (13, 3);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (21, 4);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (22, 5);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (23, 6);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (24, 7);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (25, 13);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (26, 15);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (27, 17);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (31, 8);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (32, 9);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (33, 10);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (34, 11);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (35, 12);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (36, 16);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (41, 18);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (42, 19);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (43, 20);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (44, 21);
INSERT INTO `Menu` (`MenuId`, `ItemId`) VALUES (51, 22);











