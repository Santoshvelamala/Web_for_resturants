<?php
session_start();
$id = $_SESSION['TId'];
$CNAME=$_SESSION['CNAME'];
$id= (int)$id;
echo gettype ($id );
?>
 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
//echo "<body style='background-color:pink'>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$k="ATable".$id;
//$l='A'.$k;    
echo $k;
//echo $l;
$sql = "INSERT INTO HISTORY  (TId,MenuId,Customer,DT,TM) SELECT TId,MenuId,Customer,DT,TM
FROM $k";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
$sql1="Truncate table $k";
if (mysqli_query($conn, $sql1)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
}
redirect ("/Fcomm/Mhome.php");
function redirect($url, $permanent = false) {
	if($permanent) {
		header('HTTP/1.1 301 Moved Permanently');
	}
	header('Location: '.$url);
	exit();
}
$conn->close();

?>
 

