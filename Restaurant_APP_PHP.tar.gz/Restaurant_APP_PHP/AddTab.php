 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if($conn ==false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$var=$_POST['Table_Name'];
$var1=$_POST['password'];

$sql =	"INSERT INTO Tables (Table_Name,password) VALUES
            ('$var', '$var1')";

if(mysqli_query($conn, $sql)){
    header("location:AddTab.html");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

$sql2 = "CREATE TABLE $var (
     id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	TId INT(11),
     MenuId INT(11),
     Customer VARCHAR(120),
	DT date,
	TM TIME
     )";
if ($conn->query($sql2) == TRUE) {
    echo "Table MyGuests created successfully";
	//header("location:stops.html");
} else {
    echo "Error creating table: " . $conn->error;
}
$var='A'.$var;
$sql3 = "CREATE TABLE $var (
     id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	TId INT(11),
     MenuId INT(11),
     Customer VARCHAR(120),
	DT date,
	TM TIME
     )";
if ($conn->query($sql3) == TRUE) {
    echo "Table MyGuests created successfully";
	//header("location:stops.html");
} else {
    echo "Error creating table: " . $conn->error;
}

mysqli_close($conn);
?>
