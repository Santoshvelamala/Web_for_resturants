 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$var=$_POST['Item_Name'];

$sql =	"DELETE FROM Item 
	WHERE Item_Name='$var'";

if(mysqli_query($conn, $sql)){
    header("location:delete.html");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

mysqli_close($conn);
?>
