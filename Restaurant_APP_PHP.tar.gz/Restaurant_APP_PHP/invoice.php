
<?php
require("config.php");
session_start();
if(isset($_SESSION['id']))
{$id = $_SESSION['id'];
echo $id;
$orders=$_SESSION['orders'];
$orders=(int)$orders;

?>
<link rel="stylesheet" href="style.css" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css"> 
	<link rel="stylesheet" type="text/css" href="assets/css/page-style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/hexagons.min.css"> 
	<script src="assets/js/jquery-2.1.0.min.js"></script>
	<script src="assets/js/hexagons.min.js"></script>
<br><br>
<div id="container">
<div>
	 <a href="index.php"> <img src="logo.png"  align="left" style="width:200px;height:150px;"></a>
		<center><a href="#"><span class="hb hb-sm spin"><i class="fa fa-facebook"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-twitter"></i></span></a> 
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-google-plus"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-youtube"></i></span></a>
		<a href="#"><span class="hb hb-sm spin"><i class="fa fa-linkedin-square"></i></span></a></center>
	</div>
<div id="header">
<a href="/Fcomm/main.php">	<div class="button gray"><div class="shine"></div>HOME</div></a>
<a href="/Fcomm/about.php"><div class="button blue"><div class="shine"></div>ABOUT</div></a>
<a href="/Fcomm/contact.php"><div class="button purple"><div class="shine"></div>CONTACT</div></a>
<a href="/Fcomm/MLogin.php"><div class="button orange"><div class="shine"></div>Management Login</div></a>​   
	</div>
    
    <div id="primary">
	<br><br><br>
	<a class="semi-transparent-button" href="yourorders.php">YOUR ORDERS</a>
	<br>
	<a class="semi-transparent-button" href="main2.php">Menu</a>
	<br>
	<a class="semi-transparent-button" href="invoice.php">CREATE INVOICE</a>
	<br>

    </div>
    
    <div id="content" style="overflow-x:scroll ; overflow-y: scroll; padding-bottom:10px;">
        

 <?php
$servername = "localhost";
$username = "root";
$password = "santuharsha";
$dbname = "fcomm";

// Create connection
echo "<body style='background-color:pink'>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//$Album = mysqli_real_escape_string($conn, $_REQUEST['Album']);
$bust="Table".$id;
$sql = "select * from $bust natural join Menu natural join Item";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
	echo '<table border="10" bgcolor="#00FF00" align="center">'; 
echo '<caption><h1 style="color: #FFF; background: #000">Invoice</h1></caption>';

echo '<form action="invoicesubmit.php" method="post">';
echo '<tr><td>MenuId</td><td align="center">Item Name</td><td>Price</td></tr>';
$count=0;
    while($row = $result->fetch_assoc()) {
	$count=$count+$row['Price'];
	$a=$row['ItemId'];
    echo "<tr><td align='center'>"; 
	echo $row['ItemId'];
	echo "</td><td align='center'>";    
	echo $row['Item_Name'];
	echo "</td><td align='center'>";    
	echo $row['Price']." "."/-";
	echo "</td><td align='center'>";
	echo "</TD></tr>"; 
	
    }
echo "<tr><td></td><td><b>TOTAL</b></td><td> <b>Rs.$count/- </b></td></tr>";
echo '<tr><td align="center" colspan="4"><input type="submit" value ="Submit" class="button" /></td></tr>';
echo '</form>';

} else {
    echo "0 results";
}
$conn->close();
?> 
    
    
</div>
<?php } ?>

